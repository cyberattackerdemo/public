# deploy.ps1

$workdir = Split-Path -Parent $MyInvocation.MyCommand.Path

# payload*.zip を取得
$zip = Get-ChildItem "$workdir\payload*.zip" | Select-Object -First 1

if (-not $zip) {
    Write-Host "payload zip not found"
    exit 1
}

# 展開
Expand-Archive -Path $zip.FullName -DestinationPath $extractDir -Force

# payload*.exe を検索
$exe = Get-ChildItem "$extractDir\payload*.exe" -Recurse | Select-Object -First 1

if (-not $exe) {
    Write-Host "payload exe not found"
    exit 1
}

# 実行
$p = Start-Process $exe.FullName -PassThru

# プロセス終了待ち
$p.WaitForExit()

# 正常終了時のみ削除
if ($p.ExitCode -eq 0) {

    Remove-Item $extractDir -Recurse -Force
    Remove-Item $zip.FullName -Force

    Write-Host "cleanup completed"
}
else {
    Write-Host "installer exited with error"
}