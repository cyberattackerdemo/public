# first_step.ps1

# スクリプト配置ディレクトリ
$workdir = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $workdir "payload_evation_1.exe"

if (-not (Test-Path $target)) {
    Write-Host "target not found"
    exit 1
}

# 実行
$p = Start-Process $target -PassThru

# 終了待機
$p.WaitForExit()

Write-Host "Process exited with code:"
Write-Host $p.ExitCode