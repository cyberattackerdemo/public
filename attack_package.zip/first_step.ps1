# first_step.ps1

# スクリプト配置ディレクトリ
$workdir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "WORKDIR: $workdir"

# EXE検索
$exe = Get-ChildItem "$extractDir\payload*.exe" -File |
       Select-Object -First 1

if (-not $exe) {
    Write-Host "payload exe not found"
    exit 1
}

Write-Host "FOUND EXE:"
Write-Host $exe.FullName

# 実行
$p = Start-Process $exe.FullName -PassThru

# 終了待機
$p.WaitForExit()

Write-Host "Process exited with code:"
Write-Host $p.ExitCode