# deploy.ps1

$workdir = Split-Path -Parent $MyInvocation.MyCommand.Path

# payload*.exe を検索
$exe = Get-ChildItem "$extractDir\payload*.exe" -Recurse | Select-Object -First 1

if (-not $exe) {
    Write-Host "payload exe not found"
    exit 1
}

# 実行
$p = Start-Process $exe.FullName -PassThru

# プロセス終了待ち
$p.WaitForExit()

# 正常終了時のみ削除
if ($p.ExitCode -eq 0) {

    Remove-Item $extractDir -Recurse -Force
    Remove-Item $zip.FullName -Force

    Write-Host "cleanup completed"
}
else {
    Write-Host "installer exited with error"
}