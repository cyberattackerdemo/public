# first_step.ps1

# スクリプト配置ディレクトリ
$workdir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "WORKDIR: $workdir"

# ZIP取得
$zip = Get-ChildItem "$workdir\payload*.zip" |
       Select-Object -First 1

if (-not $zip) {
    Write-Host "payload zip not found"
    exit 1
}

Write-Host "ZIP:"
Write-Host $zip.FullName

# 展開先
$extractDir = Join-Path $workdir "extract"

# 展開
Expand-Archive `
    -Path $zip.FullName `
    -DestinationPath $extractDir `
    -Force

Write-Host "EXTRACT DIR:"
Write-Host $extractDir

# EXE検索
$exe = Get-ChildItem "$extractDir\payload*.exe" -File |
       Select-Object -First 1

if (-not $exe) {
    Write-Host "payload exe not found"
    exit 1
}

Write-Host "FOUND EXE:"
Write-Host $exe.FullName

# 実行
$p = Start-Process $exe.FullName -PassThru

# 終了待機
$p.WaitForExit()

# 正常終了時
if ($p.ExitCode -eq 0) {

    Remove-Item $extractDir -Recurse -Force
    Remove-Item $zip.FullName -Force

    Write-Host "cleanup completed"
}
else {
    Write-Host "installer exited with error"
}